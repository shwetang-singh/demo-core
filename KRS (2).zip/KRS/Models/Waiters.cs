﻿using System;

namespace Models
{
    public class Waiter
    {
        public int WaiterId { get; set; }
        public string Name { get; set; }
    }
}
