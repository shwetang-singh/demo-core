﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels
{
    public class OrderDetailsDto
    {
        public Guid OrderID { get; set; }
        public int TableNo { get; set; }
        public int WaiterID { get; set; }
        public int ItemId { get; set; }
        public int Quantity { get; set; }
        public string AnySpecification { get; set; }
        public OrderStatus OrderStatus { get; set; }
    }
}
