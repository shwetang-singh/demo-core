﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
   public class KitchenArea
    {
      public int AreaId { get; set; }
        public string Name { get; set; }
    }
}
