﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
   public class Order
    {
        public Guid OrderId { get; set; }
        public int TableNo { get; set; }
        public int WaiterId { get; set; }

        public List<OrderDetail> orderDetails { get; set; }


    }
}
