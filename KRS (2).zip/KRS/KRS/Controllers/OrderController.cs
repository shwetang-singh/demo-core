﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using Models;
using Models.Seed;
using Models.ViewModels;
using Newtonsoft.Json;
using Services.Interfaces;

namespace KRS.Controllers
{
    public class OrderController : Controller
    {
        private readonly ILogger<OrderController> _logger;

        private readonly IWaiter _iWaiter;
        private readonly IDishes _iDishes;
        private readonly IKitchen _iKitchen;
        private readonly IOrders _iOrders;
        ConcurrentQueue<List<Order>> concurrentQueue = new ConcurrentQueue<List<Order>>();
        public OrderController(ILogger<OrderController> logger, IWaiter waiter, IDishes dishes, IKitchen kitchen, IOrders orders)
        {
            _logger = logger;
            _iWaiter = waiter;
            _iDishes = dishes;
            _iKitchen = kitchen;
            _iOrders = orders;
        }
        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.Kitchen = _iKitchen.getAreas().Select(x => new SelectListItem { Text = x.Name, Value = x.AreaId.ToString() }).ToList(); 
            ViewBag.Waiters = _iWaiter.GetWaiters().Select(x => new SelectListItem { Text = x.Name, Value = x.WaiterId.ToString() }).ToList();
            ViewBag.Items = new List<SelectListItem>();
            return View();
        }
        public JsonResult GetItmesByArea(int areaId)
        {
            var items = Seeds.getItems().Where(x => x.KitchenAreaId == areaId).ToList();
            return Json(items);
        }
        [HttpPost]
        public IActionResult Index(OrderDetailsDto orderDto)
        {
            var item = _iOrders.addOrder(orderDto).ToList();
            var oldorder = HttpContext.Session.GetString("order");


            if (oldorder == null)
            {
                HttpContext.Session.SetString("order", JsonConvert.SerializeObject(item));
                concurrentQueue.Enqueue(item);

            }
            else
            {
                var list = JsonConvert.DeserializeObject<List<Order>>(oldorder);
                
                concurrentQueue.Enqueue(list);
                item.AddRange(list);
                HttpContext.Session.SetString("order", JsonConvert.SerializeObject(item));
            }


            return RedirectToAction("Orders", "Order");
        }
        [HttpGet]
        public IActionResult Orders()
        {
            var OrderVM = new OrderVM();
            var orders = HttpContext.Session.GetString("order");

            OrderVM.KitchenAreas = _iKitchen.getAreas().ToList();
            OrderVM.Items = Seeds.getItems().ToList();       
            if (orders != null)
            {           
                var list = JsonConvert.DeserializeObject<List<Order>>(orders);
                OrderVM.Orders = list;
            }           
            
            return View(OrderVM);
        }
        [HttpGet]
        public JsonResult GetQueueItem()
        {
            var list = new List<Order>();
            var result = new List<Order>();
            if (HttpContext.Session.GetString("Queueorder") == null)
            {
                var orders = HttpContext.Session.GetString("order");
                 HttpContext.Session.SetString("Queueorder", orders);
                var orderList = JsonConvert.DeserializeObject<List<Order>>(orders);

                concurrentQueue.Enqueue(orderList);
            }
            else
            {
                var orders = HttpContext.Session.GetString("Queueorder");
                var orderList = JsonConvert.DeserializeObject<List<Order>>(orders);

                concurrentQueue.Enqueue(orderList);
            }
            
            while (concurrentQueue.TryDequeue(out list))
            {
                result.AddRange(list);

            }
            return Json(result);
        }

        [HttpPost]
        public JsonResult PushQueueItem(Guid orderid)
        {
            var list = new List<Order>();

            var queuedorders = HttpContext.Session.GetString("Queueorder");
            var orders = HttpContext.Session.GetString("order");
            
            var queuedorderList = JsonConvert.DeserializeObject<List<Order>>(queuedorders);
            var orderList = JsonConvert.DeserializeObject<List<Order>>(orders);
            var data = queuedorderList.Where(x => x.OrderId == orderid).ToList();
            var orderdata = orderList.Where(x => x.OrderId == orderid).ToList();
            var index = orderList.IndexOf(orderdata[0]);

            orderList.RemoveAt(index);
            queuedorderList.Remove(data[0]);
            list.AddRange(data);
           var orderdetail= data.Select(x=>x.orderDetails[0]).FirstOrDefault();
            orderdetail.OrderStatus = Models.Enums.OrderStatus.Completed;

            orderList.Add(data[0]);

            HttpContext.Session.SetString("order", JsonConvert.SerializeObject(orderList));
            
            concurrentQueue.Enqueue(queuedorderList);
            concurrentQueue.TryDequeue(out list);
            HttpContext.Session.SetString("Queueorder", JsonConvert.SerializeObject(queuedorderList));
            return Json(concurrentQueue);
            
        }
    }
}