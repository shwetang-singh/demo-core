﻿using Models;
using Models.Seed;
using Models.ViewModels;
using Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services.Implementation
{
    public class OrderService : IOrders
    {
        public IEnumerable<Order> addOrder(OrderDetailsDto orderDto)
        {
            var orders = new List<Order>();
            var id = Guid.NewGuid();
            var order = new Order()
            {
                OrderId = id,
                TableNo = orderDto.TableNo,
                WaiterId = orderDto.WaiterID,
                orderDetails = new List<OrderDetail>() {
                    new OrderDetail()
                    {
                        AnySpecification=orderDto.AnySpecification,
                        ItemId=orderDto.ItemId
                        ,OrderStatus=Models.Enums.OrderStatus.Pending,
                        Quantity=orderDto.Quantity
                      }
                }


            };
            orders.Add(order);
            return orders;

        }

        public Order getOrderById(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Order> getOrders()
        {
            throw new NotImplementedException();
        }
    }
}
