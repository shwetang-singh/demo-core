﻿using Models;
using Models.Seed;
using Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Services.Implementation
{
  public  class WaiterService : IWaiter
    {
        public string getWaiterName(int id)
        {
            return Seeds.getWaiters().Where(x=>x.WaiterId==id).Select(x=>x.Name).FirstOrDefault();
        }

        public IEnumerable<Waiter> GetWaiters()
        {
            return Seeds.getWaiters();
        }
    }
}
