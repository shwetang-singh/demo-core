﻿using Models;
using Models.Seed;
using Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services.Implementation
{
    public class DishService : IDishes
    {
        public IEnumerable<ItemDetail> GetItems()
        {

            return Seeds.getItems();
        }

        
    }
}
