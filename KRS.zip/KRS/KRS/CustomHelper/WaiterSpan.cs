﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using Models;
using Models.Seed;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KRS.CustomHelper
{
    public static class WaiterSpanHelper
    {
        public static IHtmlContent WaiterSpan(this IHtmlHelper html, int id)
        {
            var waiterName = Seeds.getWaiters().Where(x => x.WaiterId == id).Select(x => x.Name).FirstOrDefault();
            return new HtmlString($"<span>{ waiterName }</span>");
        }
           
    }
}
