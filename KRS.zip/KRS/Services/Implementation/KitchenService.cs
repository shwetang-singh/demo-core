﻿using Models;
using Models.Seed;
using Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services.Implementation
{
    public class KitchenService : IKitchen
    {
        public IEnumerable<KitchenArea> getAreas()
        {
            return Seeds.getAreas();
        }
    }
}
