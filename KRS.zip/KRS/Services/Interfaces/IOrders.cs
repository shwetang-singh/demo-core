﻿using Models;
using Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services.Interfaces
{
   public interface IOrders
    {
        IEnumerable<Order> getOrders();

        Order getOrderById(int id);

        IEnumerable<Order> addOrder(OrderDetailsDto orderDto);
    }
}
