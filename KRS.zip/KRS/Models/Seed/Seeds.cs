﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Seed
{
   public static class Seeds
    {
       public static IEnumerable<ItemDetail> getItems()
        {
            var items = new List<ItemDetail>() {
                new ItemDetail(){Discriptions="xyz",IsActive=true,ItemId=1,KitchenAreaId=1 , ItemName="xyz"},
                new ItemDetail(){Discriptions="abc",IsActive=true,ItemId=2,KitchenAreaId=2 , ItemName="abc"},
                new ItemDetail(){Discriptions="pqr",IsActive=true,ItemId=3,KitchenAreaId=2 , ItemName="pqr"}
                };
            return items;
        }

        public static IEnumerable<KitchenArea> getAreas()
        {
            var kitchenAreas = new List<KitchenArea>() {
                new KitchenArea(){AreaId=1,Name="Grill"},
                new KitchenArea(){AreaId=2,Name="Grevy"},
                new KitchenArea(){AreaId=3,Name="Dry"}
                };
            return kitchenAreas;
        }

        public static IEnumerable<Waiter> getWaiters()
        {
            var waiters = new List<Waiter>() {
                new Waiter(){WaiterId=1,Name="Tom"},
                new Waiter(){WaiterId=2,Name="Joe"},
                new Waiter(){WaiterId=3,Name="Chris"}
                };
            return waiters;
        }
    }
}
