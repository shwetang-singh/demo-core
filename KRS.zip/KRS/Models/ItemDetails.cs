﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
   public class ItemDetail
    {
        public int ItemId { get; set; }
        public int KitchenAreaId { get; set; }
        public string Discriptions { get; set; }
        public string ItemName { get; set; }
        public bool IsActive { get; set; }
    }
}
