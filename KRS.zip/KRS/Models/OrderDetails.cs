﻿using Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
   public class OrderDetail
    {
        public int ItemId { get; set; }
        public int Quantity { get; set; }
        public string AnySpecification { get; set; }
        public OrderStatus OrderStatus { get; set; }
    }


}
