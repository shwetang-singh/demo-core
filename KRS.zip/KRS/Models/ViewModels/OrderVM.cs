﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels
{
   public class OrderVM
    {
        public List<Order> Orders { get; set; }
        public List<KitchenArea> KitchenAreas { get; set; }
        public List<ItemDetail> Items { get; set; }

      
    }
}
